# NEXT_SESSION.md

- **campaign_id**: 00f8b4174f15406cbf8b0efe4b111dfa
- **campaign**: Campaña de prueba 48efc4
- **stage alcanzado**: TERRITORY_SELECTION
- **contadores**: conceptos=1 · rechazados=0 · finalistas=0 · misiones=0

## Tareas pendientes
- [ ] Avanzar la etapa actual.

## Próxima acción
- Avanzar la etapa actual.

## Prompt breve para la próxima sesión
```text
Continúa la campaña 00f8b4174f15406cbf8b0efe4b111dfa (Campaña de prueba 48efc4) siguiendo SESSION_PLAN.md. Lee AGENTS.md, SESSION_STATE.json y NEXT_SESSION.md. Ejecuta las tareas de la etapa TERRITORY_SELECTION sin pedirme confirmación, valida los resultados, importa los outputs y finaliza la sesión con finalize_session.py. No inventes evidencia ni uses APIs de pago (api_budget_usd=0). Si la campaña no supera los umbrales, ciérrala guardando el motivo.
```

## Reglas permanentes
- No gastar tokens de API en descubrimiento (api_budget_usd=0).
- No fingir que Freebuff es un runtime 24/7; esta sesión deja checkpoint.
- Ninguna campaña está obligada a producir una finalista.
- El consenso de modelos no es evidencia de mercado.
