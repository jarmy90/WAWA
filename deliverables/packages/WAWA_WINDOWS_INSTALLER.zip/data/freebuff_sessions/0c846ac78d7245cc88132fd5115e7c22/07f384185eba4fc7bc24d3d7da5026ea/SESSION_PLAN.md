# SESSION_PLAN.md

- **campaign_id**: 0c846ac78d7245cc88132fd5115e7c22
- **campaign**: Campaña de prueba 17111b
- **stage actual**: CREATED
- **session_id**: 07f384185eba4fc7bc24d3d7da5026ea
- **tiempo objetivo**: 6 h (alcance y prioridad; no es tiempo garantizado)
- **api_budget_usd**: 0.0 (política: 0 durante el descubrimiento)
- **experiment_budget_usd**: 0.0

## Restricciones
- NO usar APIs de pago ni Gemini (api_budget_usd=0).
- NO inventar demanda, precios, competidores ni evidencias (regla de no invención).
- Las evidencias solo son verified=true con URL concreta + fecha de consulta + fragmento.
- No forzar finalistas: si nada supera los umbrales, cerrar la campaña guardando el motivo.
- No aumentar los límites del embudo (
max_concepts=100, max_after_dedup=40, max_after_commodity=20, max_after_structural=10, max_after_tournament=5, maximum_finalists=3
).
- Freebuff no es un runtime 24/7: toda sesión deja checkpoint y NEXT_SESSION.md.

## Archivos que deben leerse
- AGENTS.md
- docs/FREEBUFF_SESSION_PROTOCOL.md
- docs/CAMPAIGN_RUNNER.md
- SESSION_STATE.json (junto a este plan)
- NEXT_SESSION.md de la sesión anterior (si existe)

## Tareas priorizadas
1. [ ] Avanzar la etapa actual.

## Entregables de la sesión
- SESSION_OUTPUT.json con conceptos/evidencias/misiones/revisiones (estructura de SESSION_STATE.json).
- SESSION_REPORT.md: qué se hizo, qué se verificó, qué es hipótesis, qué quedó pendiente.
- SESSION_STATE.json actualizado (lo regenera import_session_output).

## Definición de terminado
- Completar las tareas de la etapa CREATED o dejar documentado por qué no.
- Importar SESSION_OUTPUT.json y finalizar con `python3 scripts/finalize_session.py --session <id>`.

## Comando de validación
```bash
python3 -m pytest tests/ -q --tb=short
```
