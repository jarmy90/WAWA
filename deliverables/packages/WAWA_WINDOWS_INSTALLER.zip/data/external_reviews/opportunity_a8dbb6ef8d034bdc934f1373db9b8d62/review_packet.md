# Expediente de revisión externa (comité de contraste)

- **Identificador**: a8dbb6ef8d034bdc934f1373db9b8d62
- **Título**: Verificación de reseñas reales para servicios locales
- **Fecha del expediente**: 2026-08-28T18:54:44.736729+00:00
- **Sector**: discovery: Pequeños negocios / Herramienta de verificación

> Este expediente es IDÉNTICO para todos los revisores. No se adapta el texto para persuadir a ningún modelo.

## 1. Problema observado
Los clientes no distinguen reseñas reales de falsas.

## 2. Cliente objetivo
Gestor de reputación local (HIPÓTESIS).

## 3. Solución propuesta
Informe de plausibilidad de reseñas por patrones de actividad, con trazabilidad.

## 4. Contexto y evidencias guardadas
- Sin evidencias guardadas (desconocido, no cero).

## 5. Competidores, precios observados y alternativas actuales
- Sin competidores identificados.

## 6. Soluciones consideradas
Las alternativas actuales del cliente (proceso manual, freelancer, plantilla gratuita, IA generalista) se reflejan en las evidencias y en la crítica interna.

## 7. Diferenciación y canal de adquisición
- Diferenciación estimada: —/100
- Llegada a compradores: desconocida
- Autonomía de automatización estimada: desconocida%

## 8. Coste, modelo de ingresos y margen (ESTIMACIONES)
- Coste de construcción (USD): desconocido – desconocido
- Precio estimado (USD): desconocido – desconocido
- Margen estimado (%): desconocido – desconocido
- Recurrencia: desconocida
- Dependencias de plataforma: ninguna declarada
> Las cifras sin fuente son ESTIMACIONES. Si no hay dato, se indica 'desconocido'.

## 9. Datos desconocidos y suposiciones no verificadas
- Suposiciones sin verificar: 0

## 10. Riesgos (Compliance) y crítica interna (Skeptic)
- Sin riesgos declarados.


## 11. Experimento propuesto
- Sin experimento definido.

## 12. Preguntas concretas para el revisor
- ¿Qué supuesto, si fuera falso, destruiría la oportunidad?
- ¿Qué evidencia externa concreta (URL + fecha + fragmento) falta y es imprescindible?
- ¿Quién pagaría exactamente y de qué presupuesto saldría el pago?
- ¿Cuál es la alternativa real del cliente hoy y qué le costaría no resolver el problema?
- ¿Puede una IA generalista (ChatGPT/Gemini/Claude/DeepSeek) resolver el 80% del problema con un prompt?
- ¿Cómo conseguiría los primeros 20 usuarios sin spam?
- ¿Cuál es el experimento MÁS BARATO que probaría la hipótesis con señal real?
- ¿Qué condición objetiva obligaría a abandonar?

## 13. Prompt de revisión normalizado

Actúa como revisor empresarial independiente y adversarial.

Tu trabajo no es apoyar la propuesta, sino determinar si merece más investigación o una prueba limitada.

Utiliza exclusivamente el expediente proporcionado.

No inventes demanda, cifras, competidores, precios ni capacidades.

Separa hechos, inferencias y supuestos.

Evalúa:

1. Claridad y gravedad del problema.
2. Cliente objetivo.
3. Evidencia de demanda.
4. Disposición a pagar.
5. Acceso al cliente.
6. Competencia.
7. Diferenciación.
8. Modelo de ingresos.
9. Margen.
10. Automatización.
11. Coste y velocidad de construcción.
12. Dependencia de terceros.
13. Riesgo legal y operativo.
14. Calidad del experimento.
15. Supuesto más débil.
16. Evidencia crítica que falta.
17. Alternativa mejor.
18. Motivo principal para continuar.
19. Motivo principal para rechazar.

Devuelve:

- recommendation:
  REJECT
  MORE_RESEARCH
  SMALL_EXPERIMENT
  PRIORITY_EXPERIMENT

- confidence: 0-100
- strongest_evidence
- weakest_assumption
- missing_evidence
- primary_risk
- suggested_improvement
- cheaper_experiment
- kill_condition
- final_reasoning_summary

No confundas una idea original con una oportunidad comercial.
