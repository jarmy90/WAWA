# Expediente de revisión externa (comité de contraste)

- **Identificador**: 5cfe720b700645cdb40f590885cfe599
- **Título**: Conciliación de inventario físico-online para pequeños comercios
- **Fecha del expediente**: 2026-08-28T18:58:01.524222+00:00
- **Sector**: retail

> Este expediente es IDÉNTICO para todos los revisores. No se adapta el texto para persuadir a ningún modelo.

## 1. Problema observado
Los pequeños comercios con tienda física y online pierden ventas y margen porque el stock no coincide entre canales: venden lo que no tienen, cancelan pedidos y pasan horas reconciliando hojas de cálculo a mano.

## 2. Cliente objetivo
Comercios minoristas con menos de 50 empleados que venden en tienda física y online (p. ej. tiendas de moda o ferretería con Shopify + caja registradora).

## 3. Solución propuesta
Servicio de conciliación automática de inventario entre canales: integración ligera, detección de discrepancias, alertas accionables e informe semanal. Análisis de datos, sin prometer resultados de venta.

## 4. Contexto y evidencias guardadas
- **[demand_signal]** DEMO: comerciantes consultados en foros de retail mencionan cancelaciones por falta de stock entre canales. Dato sintético, NO evidencia real de mercado.
  - Fuente: (dato sintético de demostración) 
  - Fiabilidad: 0.5 · Verificada: no · Método: demo
  - Notas: Material de demostración; no existe URL verificable real.
- **[customer_profile]** DEMO: perfiles hipotéticos de comercios mixtos físico+online con 1-50 empleados. Dato sintético, NO evidencia real.
  - Fuente: (dato sintético de demostración) 
  - Fiabilidad: 0.5 · Verificada: no · Método: demo
  - Notas: Material de demostración; no existe URL verificable real.
- **[technical]** DEMO: Shopify y cajas registradoras exponen APIs de inventario; la conciliación es técnicamente viable. Dato sintético, NO evidencia real.
  - Fuente: (dato sintético de demostración) 
  - Fiabilidad: 0.4 · Verificada: no · Método: demo
  - Notas: Material de demostración; no existe URL verificable real.
- **[demand_signal]** DESCONOCIDO: no se ha recopilado evidencia externa verificada de demanda en modo sin API. Este dato debe investigarse manualmente (o con Gemini) antes de aprobar.
  - Fuente: (modo offline — sin investigación externa) 
  - Fiabilidad: 0.0 · Verificada: no · Método: mock (deterministic, offline)
  - Notas: Entrada generada por el proveedor simulado: marca el dato como desconocido, no lo inventa.

## 5. Competidores, precios observados y alternativas actuales
- **(competidor sintético) app de inventario genérica** — Herramienta genérica de inventario sin conciliación entre canales. · precio observado: desconocido USD
  - Fortalezas: Marca conocida, base instalada.
  - Debilidades: No detecta discrepancias físico-online; configuración compleja; sin informe accionable.

## 6. Soluciones consideradas
Las alternativas actuales del cliente (proceso manual, freelancer, plantilla gratuita, IA generalista) se reflejan en las evidencias y en la crítica interna.

## 7. Diferenciación y canal de adquisición
- Diferenciación estimada: 80.0/100
- Llegada a compradores: DESCONOCIDO: no hay canales verificados para llegar a compradores en modo offline
- Autonomía de automatización estimada: 70%

## 8. Coste, modelo de ingresos y margen (ESTIMACIONES)
- Coste de construcción (USD): 100.0 – 350.0
- Precio estimado (USD): desconocido – desconocido
- Margen estimado (%): desconocido – desconocido
- Recurrencia: uno a uno (servicio puntual); posible retención con informes recurrentes
- Dependencias de plataforma: ninguna declarada
> Las cifras sin fuente son ESTIMACIONES. Si no hay dato, se indica 'desconocido'.

## 9. Datos desconocidos y suposiciones no verificadas
- Suposiciones sin verificar: 6
  - Precio: DESCONOCIDO: no hay precios observados guardados.
  - Margen estimado para servicios digitales (55-85%) si el precio se confirma; sin confirmar es desconocido.
  - Tasa diaria asumida de 50 USD/día (estimación).
  - Complejidad estimada por heurística de sector.
  - Riesgo low: Los logs pueden contener datos de cuenta. Minimizar retención y permitir borrado.
  - Sin suposiciones declaradas.

## 10. Riesgos (Compliance) y crítica interna (Skeptic)
- [low] privacidad: Los logs pueden contener datos de cuenta. Minimizar retención y permitir borrado.
  - Mitigación: Procesar localmente; no almacenar más de lo necesario; anonimizar.

### Crítica interna
No hay ninguna evidencia verificada. La demanda, los precios, los competidores y el perfil de cliente son desconocidos: no se puede afirmar que exista un mercado real. Una idea bien redactada no es una oportunidad demostrada.

## 11. Experimento propuesto
- Sin experimento definido.

## 12. Preguntas concretas para el revisor
- ¿Qué supuesto, si fuera falso, destruiría la oportunidad?
- ¿Qué evidencia externa concreta (URL + fecha + fragmento) falta y es imprescindible?
- ¿Quién pagaría exactamente y de qué presupuesto saldría el pago?
- ¿Cuál es la alternativa real del cliente hoy y qué le costaría no resolver el problema?
- ¿Puede una IA generalista (ChatGPT/Gemini/Claude/DeepSeek) resolver el 80% del problema con un prompt?
- ¿Cómo conseguiría los primeros 20 usuarios sin spam?
- ¿Cuál es el experimento MÁS BARATO que probaría la hipótesis con señal real?
- ¿Qué condición objetiva obligaría a abandonar?

## 13. Prompt de revisión normalizado

Actúa como revisor empresarial independiente y adversarial.

Tu trabajo no es apoyar la propuesta, sino determinar si merece más investigación o una prueba limitada.

Utiliza exclusivamente el expediente proporcionado.

No inventes demanda, cifras, competidores, precios ni capacidades.

Separa hechos, inferencias y supuestos.

Evalúa:

1. Claridad y gravedad del problema.
2. Cliente objetivo.
3. Evidencia de demanda.
4. Disposición a pagar.
5. Acceso al cliente.
6. Competencia.
7. Diferenciación.
8. Modelo de ingresos.
9. Margen.
10. Automatización.
11. Coste y velocidad de construcción.
12. Dependencia de terceros.
13. Riesgo legal y operativo.
14. Calidad del experimento.
15. Supuesto más débil.
16. Evidencia crítica que falta.
17. Alternativa mejor.
18. Motivo principal para continuar.
19. Motivo principal para rechazar.

Devuelve:

- recommendation:
  REJECT
  MORE_RESEARCH
  SMALL_EXPERIMENT
  PRIORITY_EXPERIMENT

- confidence: 0-100
- strongest_evidence
- weakest_assumption
- missing_evidence
- primary_risk
- suggested_improvement
- cheaper_experiment
- kill_condition
- final_reasoning_summary

No confundas una idea original con una oportunidad comercial.
