# Expediente de revisión externa (comité de contraste)

- **Identificador**: e5c57d7d6871413fb26d51cd3bc7c476
- **Título**: Benchmark anónimo de tarifas para clínicas dentales que deciden su precio de ortodoncia
- **Fecha del expediente**: 2026-08-28T13:51:46.029116+00:00
- **Sector**: discovery: Información difícil de verificar / Producto prosumer

> Este expediente es IDÉNTICO para todos los revisores. No se adapta el texto para persuadir a ningún modelo.

## 1. Problema observado
Las clínicas dentales pequeñas fijan el precio de ortodoncia sin un comparativo de tarifas de su zona y pierden margen o pacientes.

## 2. Cliente objetivo
Gerentes de clínicas dentales de 2-5 dentistas.

## 3. Solución propuesta
Encuesta de tarifas anónima entre clínicas de la misma provincia con informe comparativo trimestral.

## 4. Contexto y evidencias guardadas
- **[demand_signal]** Aseguradora sanitaria publica tarifario de tratamientos; el precio depende de estudios y diagnostico por paciente.
  - Fuente: Sanitas Dental - precios tratamientos https://www.sanitas.es/dental/precios-tratamientos-dentales
  - Fiabilidad: 0.7 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual de la pagina.
- **[price]** Clinica publica rango de 2.900-8.100 EUR: dispersion amplia segun tipo de ortodoncia.
  - Fuente: Clínica Friedlander - precio ortodoncia https://www.clinicafriedlander.com/precio-de-ortodoncia/
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[price]** Guia de precios por ciudad: cada clinica fija tarifas dentro de rangos publicados.
  - Fuente: Prodentis - guia precios dentales Málaga 2026 https://www.prodentis.es/blog/guia-precios-dentales-malaga-2026
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[customer_profile]** Las clinicas compiten publicando precios de brackets e invisible; el gerente decide tarifas.
  - Fuente: Clínica Dental Nobel - coste brackets España https://clinicadentalnobel.es/costo-de-los-brackets-dentales-en-espana/
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[other]** Alternativa actual: articulos genericos y calculo manual de costes para fijar precios.
  - Fuente: Doctocliq - fijar precio tratamientos dentales https://www.doctocliq.com/blog/fijar-precio-de-tratamientos-dentales
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[other]** Alternativa de pago: formacion y consultoria sobre factores que influyen en precios.
  - Fuente: Dental Data School - cómo fijar precio en clínicas https://dentaldataschool.es/articulos/como-fijar-precio-clinica-dental/
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[competitor]** Software de gestion clinica con estudio de mercado y KPIs: competidor indirecto.
  - Fuente: Infomed - KPIs y estudio de mercado para clínicas https://www.infomedsoftware.com/tam-sam-som-ltv-kpis-nps-estudio-mercado-dashboard-valor-rentabilidad/
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[customer_profile]** Directorio oficial del Consejo General con contacto de colegios provinciales: canal hacia gerentes de clinicas.
  - Fuente: GuiaDentistas - Consejo General de Dentistas https://guiadentistas.es/
  - Fiabilidad: 0.7 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[customer_profile]** Listado oficial de colegios provinciales: punto de acceso institucional al colectivo.
  - Fuente: Consejo Dentistas - colegios oficiales https://consejodentistas.es/consejo-general/colegios-oficiales/
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[other]** Fijar precios depende de estrategia y contexto local del negocio: no es una respuesta generica.
  - Fuente: Dental Tribune - cómo fijar honorarios https://la.dental-tribune.com/news/como-fijar-honorarios-en-odontologia-el-miedo-al-precio-y-el-poder-del-valor/
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.
- **[price]** Cada clinica publica su propia tarifa sin estandar de mercado: la dispersion real no es publica de forma agregada.
  - Fuente: Clínica Ferrús Bràtos - precios tratamientos https://www.clinicaferrusbratos.com/odontologia-general/precios-tratamientos-dentales/
  - Fiabilidad: 0.6 · Verificada: sí · Método: manual
  - Notas: URL + fecha de consulta + fragmento textual.

## 5. Competidores, precios observados y alternativas actuales
- **Dental Data School** — Formacion y consultoria para fijar precios en clinicas dentales · precio observado: desconocido USD
  - Fortalezas: Contenido especifico del sector
  - Debilidades: Formacion generica, sin benchmark anonimo local por provincia
- **Doctocliq** — Contenido y herramientas para fijar precios de tratamientos · precio observado: desconocido USD
  - Fortalezas: Contenido accesible
  - Debilidades: Sin datos locales de mercado
- **Infomed Software** — Software de gestion clinica con KPIs y estudio de mercado · precio observado: desconocido USD
  - Fortalezas: Software instalado en clinicas
  - Debilidades: No publica benchmark anonimo de tarifas de competidores

## 6. Soluciones consideradas
Las alternativas actuales del cliente (proceso manual, freelancer, plantilla gratuita, IA generalista) se reflejan en las evidencias y en la crítica interna.

## 7. Diferenciación y canal de adquisición
- Diferenciación estimada: 0.0/100
- Llegada a compradores: desconocida
- Autonomía de automatización estimada: desconocida%

## 8. Coste, modelo de ingresos y margen (ESTIMACIONES)
- Coste de construcción (USD): desconocido – desconocido
- Precio estimado (USD): desconocido – desconocido
- Margen estimado (%): desconocido – desconocido
- Recurrencia: desconocida
- Dependencias de plataforma: ninguna declarada
> Las cifras sin fuente son ESTIMACIONES. Si no hay dato, se indica 'desconocido'.

## 9. Datos desconocidos y suposiciones no verificadas
- Suposiciones sin verificar: 3
  - Comprador (gerente de clínica 2-5 dentistas) pagaría por un informe de tarifas: HIPÓTESIS no verificada con comprador real.
  - Presupuesto real de la clínica por este informe: HIPÓTESIS (30-90 EUR).
  - Urgencia/evento de compra: no detectado en evidencia.

## 10. Riesgos (Compliance) y crítica interna (Skeptic)
- Sin riesgos declarados.

### Crítica interna
El comprador puede resolver con guías de precios gratuitas; la urgencia no está demostrada; el dominio sanitario exige no tocar datos de pacientes. Por eso la decisión es un experimento pequeño y barato, no un lanzamiento.

## 11. Experimento propuesto
- Sin experimento definido.

## 12. Preguntas concretas para el revisor
- ¿Qué supuesto, si fuera falso, destruiría la oportunidad?
- ¿Qué evidencia externa concreta (URL + fecha + fragmento) falta y es imprescindible?
- ¿Quién pagaría exactamente y de qué presupuesto saldría el pago?
- ¿Cuál es la alternativa real del cliente hoy y qué le costaría no resolver el problema?
- ¿Puede una IA generalista (ChatGPT/Gemini/Claude/DeepSeek) resolver el 80% del problema con un prompt?
- ¿Cómo conseguiría los primeros 20 usuarios sin spam?
- ¿Cuál es el experimento MÁS BARATO que probaría la hipótesis con señal real?
- ¿Qué condición objetiva obligaría a abandonar?

## 13. Prompt de revisión normalizado

Actúa como revisor empresarial independiente y adversarial.

Tu trabajo no es apoyar la propuesta, sino determinar si merece más investigación o una prueba limitada.

Utiliza exclusivamente el expediente proporcionado.

No inventes demanda, cifras, competidores, precios ni capacidades.

Separa hechos, inferencias y supuestos.

Evalúa:

1. Claridad y gravedad del problema.
2. Cliente objetivo.
3. Evidencia de demanda.
4. Disposición a pagar.
5. Acceso al cliente.
6. Competencia.
7. Diferenciación.
8. Modelo de ingresos.
9. Margen.
10. Automatización.
11. Coste y velocidad de construcción.
12. Dependencia de terceros.
13. Riesgo legal y operativo.
14. Calidad del experimento.
15. Supuesto más débil.
16. Evidencia crítica que falta.
17. Alternativa mejor.
18. Motivo principal para continuar.
19. Motivo principal para rechazar.

Devuelve:

- recommendation:
  REJECT
  MORE_RESEARCH
  SMALL_EXPERIMENT
  PRIORITY_EXPERIMENT

- confidence: 0-100
- strongest_evidence
- weakest_assumption
- missing_evidence
- primary_risk
- suggested_improvement
- cheaper_experiment
- kill_condition
- final_reasoning_summary

No confundas una idea original con una oportunidad comercial.
