"""Configuración centralizada del proyecto.

Todas las opciones se pueden sobreescribir con variables de entorno o un
archivo ``.env`` (ver ``.env.example``). Ningún valor es obligatorio:
el sistema arranca y funciona sin ninguna clave de API.
"""
from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parents[2]

DEFAULT_SCORING_WEIGHTS: dict[str, float] = {
    "pain": 0.20,
    "demand": 0.20,
    "customer_reach": 0.15,
    "automation": 0.15,
    "margin": 0.10,
    "build_speed": 0.10,
    "differentiation": 0.05,
    "safety": 0.05,
}

DEFAULT_DECISION_BANDS: list[dict[str, Any]] = [
    {"min_score": 75, "decision": "approved"},
    {"min_score": 60, "decision": "needs_more_research"},
    {"min_score": 40, "decision": "deferred"},
    {"min_score": 0, "decision": "rejected"},
]


class Settings(BaseSettings):
    """Configuración central. Se lee de variables de entorno y de `.env`."""

    model_config = SettingsConfigDict(
        env_file=str(PROJECT_ROOT / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # --- Identidad -----------------------------------------------------
    app_name: str = "Autonomous Business Lab"
    version: str = "0.25.0"
    log_level: str = "INFO"

    # --- Rutas ---------------------------------------------------------
    data_dir: Path = PROJECT_ROOT / "data"
    database_path: Path = PROJECT_ROOT / "data" / "abl.db"
    logs_dir: Path = PROJECT_ROOT / "data" / "logs"
    manual_research_dir: Path = PROJECT_ROOT / "data" / "manual_research"
    frontend_dir: Path = PROJECT_ROOT / "frontend"
    # Credenciales del asistente CONECTAR SERVICIOS (iteración 022): archivo
    # LOCAL fuera de Git (`.env`). En tests se redirige a un directorio temporal.
    credentials_env_path: Path = PROJECT_ROOT / ".env"

    # --- Proveedores LLM ------------------------------------------------
    llm_provider: Literal["auto", "mock", "gemini", "manual", "openrouter"] = "auto"
    gemini_api_key: str | None = None
    gemini_model: str = "gemini-1.5-flash"
    gemini_request_timeout: float = 60.0
    openrouter_api_key: str | None = None
    # Modelo FIJO del comité (comparabilidad entre revisiones).
    openrouter_review_model: str = "openai/gpt-4o-mini"
    # Router gratuito como fallback; el modelo real usado puede variar por llamada
    # (se registra siempre `actual_model` en el log de llamadas).
    openrouter_fallback_model: str = "openrouter/free"
    openrouter_timeout_seconds: float = 60.0
    openrouter_max_retries: int = 2
    openrouter_max_input_tokens: int = 6_000
    openrouter_max_output_tokens: int = 2_000
    openrouter_daily_request_limit: int = 30
    openrouter_daily_cost_limit_usd: float = 0.50
    openrouter_monthly_cost_limit_usd: float = 5.00
    openrouter_max_reviews_per_opportunity: int = 1
    openrouter_circuit_breaker_failures: int = 5
    openrouter_circuit_breaker_cooldown_seconds: int = 300

    # --- OmniRoute (OPCIONAL, AISLADO, desactivado por defecto; iteración 008) -
    # Gateway local OpenAI-compatible, servicio separado. NO sustituye a
    # OpenRouter; nunca se usa para Discovery general hasta pasar un A/B.
    omniroute_enabled: bool = False
    omniroute_base_url: str = "http://127.0.0.1:20128/v1"
    omniroute_api_key: str | None = None  # clave del gateway local (gestor de secretos)
    omniroute_cli_token: str | None = None  # header x-omniroute-cli-token (authz local)
    omniroute_review_model: str = "auto"
    omniroute_discovery_model: str = "auto"
    omniroute_fallback_model: str = "auto"
    omniroute_timeout_seconds: float = 60.0
    omniroute_max_retries: int = 1
    omniroute_max_input_tokens: int | None = None
    omniroute_max_output_tokens: int | None = None
    omniroute_daily_request_limit: int = 20
    omniroute_daily_cost_limit_usd: float = 0.0
    omniroute_monthly_cost_limit_usd: float = 0.0
    omniroute_allow_free_only: bool = True
    omniroute_require_model_id: bool = True

    # --- Ventana prioritaria OX Alpha (iteración 015) ---------------------
    # El propietario dispone de acceso gratuito TEMPORAL al modelo que denomina
    # "OX Alpha" HASTA 2026-08-27 (inclusive). Reglas inmutables:
    #   1. NO se inventa el slug: ox_alpha_slug SOLO se fija tras verificar el
    #      catálogo real del gateway (GET /models). Vacío => OX_ALPHA_UNVERIFIED
    #      y NUNCA se declara que se ha usado OX Alpha.
    #   2. Tras la fecha de expiración la puerta se cierra sola (sin flujos
    #      dependientes) y OmniRoute vuelve a su routing coordinado habitual.
    #   3. Las respuestas son MODEL_REASONING/HYPOTHESIS/CRITIQUE/REFORMULATION:
    #      jamás evidencia, jamás suben proven_demand ni aprueban finalistas.
    #   4. Fallo => ausencia NEUTRAL registrada; nunca sustitución silenciosa
    #      por mock ni salida sintética presentada como OX Alpha.
    ox_alpha_slug: str = ""  # slug EXACTO verificado en el catálogo; vacío = sin verificar
    ox_alpha_expires_at: str = "2026-08-27"  # último día (inclusive) de la ventana gratuita
    ox_alpha_daily_task_limit: int = 40  # tope diario de tareas profundas (anti-gasto)
    ox_alpha_max_input_chars: int = 24_000  # recorte defensivo del expediente enviado

    # --- BudgetGuard ----------------------------------------------------
    free_mode: bool = True
    simulation_mode: bool = True
    daily_budget_usd: float = 0.50
    per_opportunity_budget_usd: float = 0.20
    max_deep_evaluations_per_day: int = 5

    # --- Puntuación -----------------------------------------------------
    scoring_weights_json: str | None = None
    decision_bands_json: str | None = None

    # --- Modo de operación (ver docs/OPERATING_MODES.md) ------------------
    # AUTONOMOUS_PRODUCTION está DESACTIVADO por defecto y bloqueado por una
    # regla explícita de capacidad (production_capability_available=false).
    # Una variable de entorno puede, como máximo, llevar al sistema a
    # PRODUCTION_ARMED. La activación final sigue bloqueada en esta iteración
    # (no existe economía real ni integración financiera verificada).
    operating_mode: Literal[
        "development_and_review", "simulation", "shadow_mode", "production_armed",
        "autonomous_production", "safe_pause", "autonomous_24_7",
    ] = "development_and_review"

    # --- Autonomous 24/7 Runtime (iteración 025) ------------------------
    # WAWA_OPERATING_MODE controla el modo de operación del runtime.
    wawa_operating_mode: str = "FREEBUFF_SESSION_ONLY"

    # Scheduler & Worker (solo un proceso; duplicados por Uvicorn son un error)
    autonomous_runtime_enabled: bool = False
    autonomous_scheduler_enabled: bool = False
    autonomous_worker_enabled: bool = False
    autonomous_poll_interval_seconds: int = 15
    autonomous_max_concurrent_jobs: int = 2
    autonomous_job_lease_seconds: int = 600

    # OmniRoute como runtime principal del modo autónomo
    # (campos adicionales; los base ya existen más arriba)
    omniroute_model_allowlist: str = ""  # CSV de slugs permitidos
    omniroute_default_model: str = "auto"

    # LLM limits for autonomous runtime
    llm_max_requests_per_minute: int = 10
    llm_max_requests_per_day: int = 500
    llm_max_tokens_per_job: int = 12000
    llm_max_tokens_per_day: int = 150000
    llm_max_estimated_cost_usd_per_day: float = 0.0
    llm_hard_budget_enforcement: bool = True
    llm_max_retries: int = 2
    llm_circuit_failure_threshold: int = 5
    llm_circuit_cooldown_seconds: int = 900

    # Permission gates for autonomous mode (all false/locked by default)
    autonomous_allow_real_research: bool = True
    autonomous_allow_external_reads: bool = True
    autonomous_allow_external_writes: bool = False
    autonomous_allow_outbound_contact: bool = False
    autonomous_allow_publication: bool = False
    autonomous_allow_financial_actions: bool = False
    autonomous_allow_code_execution: bool = False
    autonomous_allow_production_deployment: bool = False
    engine_activation_key: str | None = None

    # --- Capacidad de producción (regla explícita, auditable) -------------
    # false => AUTONOMOUS_PRODUCTION inaccesible aunque exista clave.
    production_capability_available: bool = False
    production_block_reason: str = "Real financial execution is not implemented or verified"

    # --- Economía (fase AUTONOMOUS_PRODUCTION; por defecto todo desactivado)
    # El capital es un LÍMITE MÁXIMO DE RIESGO, no una obligación de gasto.
    base_currency: str = "USD"
    money_decimals: int = 2
    capital_total_usd: float = 0.0
    reserve_intocable_usd: float = 0.0
    operating_budget_usd: float = 0.0
    max_daily_spend_usd: float = 0.0
    max_per_experiment_usd: float = 0.0
    max_simultaneous_experiments: int = 1
    # DEPRECADO (iteración 010): sustituido por cycle_length_days=30.
    # Se conserva por compatibilidad de estado/API, pero un validator lo fija
    # SIEMPRE a 30 para impedir divergencias. No usar en cálculos nuevos.
    initial_cycle_days: int = 30
    report_period: Literal["daily", "weekly", "monthly", "disabled"] = "weekly"
    alerts_mode: Literal["critical_only", "all", "disabled"] = "critical_only"

    # --- Umbrales de supervivencia (deterministas, configurables) ----------
    survival_watch_days: float = 7.0
    survival_critical_days: float = 3.0

    # --- Seguridad / límites --------------------------------------------
    max_upload_bytes: int = 1_000_000
    allowed_import_extensions: tuple[str, ...] = (".json",)
    # Iteración 010: CORS local restrictivo por defecto (no "*"). El panel
    # solo se sirve en 127.0.0.1/localhost. No exponer a Internet sin auth.
    cors_origins: list[str] = Field(default_factory=lambda: ["http://127.0.0.1:8000", "http://localhost:8000"])

    # --- Comité de contraste (revisiones externas, iteración 005) -----------
    # Las revisiones de modelos son OPINIÓN, nunca evidencia. Los umbrales
    # son configurables y deterministas; la ausencia de revisión es NEUTRAL.
    external_reviews_dir: Path = PROJECT_ROOT / "data" / "external_reviews"
    # Sesiones Freebuff-first (iteración 006): checkpoints persistentes.
    freebuff_sessions_dir: Path = PROJECT_ROOT / "data" / "freebuff_sessions"
    review_min_internal_score: float = 72.0
    review_max_finalists_per_week: int = 3
    review_window_hours: int = 48
    review_continue_without_review: bool = True
    review_required_for_sensitive_activities: bool = True
    review_max_file_bytes: int = 200_000
    review_allowed_extensions: tuple[str, ...] = (".txt", ".md", ".markdown", ".json")
    # Iteración 009: mínimo de GRUPOS de evidencia independientes para entrar
    # en el comité (además del umbral interno). Deterministica y configurable.
    review_min_evidence_groups: int = 3
    review_packet_version: str = "1"

    # --- Ciclo económico inicial (iteración 010) --------------------------
    # ÚNICA fuente de verdad: 30 días y 50 USD de capital máximo. La vía A
    # exige 50 USD de ingresos CONFIRMADOS reales; la vía B exige >=1 pago
    # real confirmado + condiciones y concede UNA prórroga de 14 días.
    # Ningún ingreso simulado cuenta. El reloj NO arranca hasta POST /cycle/start
    # (activación deliberada; estado inicial PRE_CYCLE).
    cycle_length_days: int = 30
    cycle_capital_usd: float = 50.0
    cycle_extension_days: int = 14
    cycle_max_extensions: int = 1
    cycle_checkpoint_day: int = 20  # control intermedio
    max_products_buildable: int = 2  # máximo productos construidos en el ciclo
    max_experiments_per_cycle: int = 3  # máximo experimentos
    max_pivots_per_product: int = 1  # máximo pivotes por producto
    # Método permitido para confirmar un pago real. Vacío = NO existe todavía
    # (sin integración financiera real): precondición del ciclo NO cumplida.
    real_payment_confirmation_method: str = ""

    # ------------------------------------------------------------------
    @model_validator(mode="after")
    def _pin_deprecated_cycle_days(self) -> "Settings":
        """ITERACIÓN 010: initial_cycle_days está DEPRECADO; la única fuente de
        verdad es cycle_length_days. Se fuerza a 30 para impedir divergencias
        (la prueba test_cycle_single_source detecta cualquier separación)."""
        self.initial_cycle_days = self.cycle_length_days
        return self

    def scoring_weights(self) -> dict[str, float]:
        """Pesos de los 8 criterios (0..1, deben sumar 1)."""
        if self.scoring_weights_json:
            try:
                data = json.loads(self.scoring_weights_json)
            except json.JSONDecodeError:
                return dict(DEFAULT_SCORING_WEIGHTS)
            merged = dict(DEFAULT_SCORING_WEIGHTS)
            merged.update({k: float(v) for k, v in data.items() if k in merged})
            return merged
        return dict(DEFAULT_SCORING_WEIGHTS)

    def decision_bands(self) -> list[dict[str, Any]]:
        """Banda de decisión: [(min_score, decision)] ordenadas descendentemente."""
        if self.decision_bands_json:
            try:
                data = json.loads(self.decision_bands_json)
            except json.JSONDecodeError:
                data = []
            if isinstance(data, list) and data:
                return sorted(data, key=lambda b: -float(b.get("min_score", 0)))
        return list(DEFAULT_DECISION_BANDS)

    def ensure_dirs(self) -> None:
        """Crea los directorios de datos necesarios (idempotente)."""
        for d in (
            self.data_dir,
            self.logs_dir,
            self.manual_research_dir / "requests",
            self.manual_research_dir / "responses",
            self.frontend_dir,
            self.external_reviews_dir,
            self.freebuff_sessions_dir,
        ):
            d.mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    """Singleton de configuración (cacheado)."""
    settings = Settings()
    settings.ensure_dirs()
    return settings
